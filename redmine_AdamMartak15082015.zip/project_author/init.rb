require 'redmine'

require_dependency 'project_author/hooks'
require_dependency 'project_author/project_patch'

Redmine::Plugin.register :project_author do
  name 'Project Author plugin'
  author 'Adam Marťák'
  description 'Add author to project'
  version '0.0.1'
  url 'http://example.com/path/to/plugin'
  author_url 'http://example.com/about'
end
