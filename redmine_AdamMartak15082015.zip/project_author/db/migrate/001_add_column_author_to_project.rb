class AddColumnAuthorToProject < ActiveRecord::Migration
    def self.up
        add_reference :projects, :author, references: :users, index: true
        add_foreign_key :projects, :users, column: :author_id
    end

    def self.down
        remove_reference :projects, :author
        remove_foreign_key :projects, :users, column: :author_id
    end
end
