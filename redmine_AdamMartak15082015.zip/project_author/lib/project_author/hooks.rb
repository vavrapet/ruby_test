module ProjectAuthor
  class Hooks < Redmine::Hook::ViewListener
    render_on :view_projects_form,
              :partial => 'hooks/project_author/view_projects_form_author'
  end
end
