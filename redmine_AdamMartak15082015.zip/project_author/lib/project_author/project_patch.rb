require_dependency 'project'
require_dependency 'user'

module ProjectAuthor
  module UserPatch

    def self.included(base) # :nodoc:
      base.extend(ClassMethods)
      base.send(:include, InstanceMethods)

      # Exectue this code at the class level (not instance level)
      base.class_eval do
        unloadable # Send unloadable so it will not be unloaded in development

        belongs_to :author, class_name: 'User', foreign_key: 'author_id'
        validates :author, presence: true

        safe_attributes 'author_id'
      end #base.class_eval

    end #self.included

    module ClassMethods
    end

    module InstanceMethods
    end #InstanceMethods

  end

end

unless Project.included_modules.include? ProjectAuthor::UserPatch
  Project.send(:include, ProjectAuthor::UserPatch)
end
