module Project_model_patch
  def self.included(base)
    base.class_eval do
      belongs_to :user
      safe_attributes "user_id"
    end
  end
end