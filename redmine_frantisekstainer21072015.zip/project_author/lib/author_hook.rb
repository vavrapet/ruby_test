class AuthorHook < Redmine::Hook::ViewListener
  render_on :view_projects_form,
    :partial => 'projects/author_field'
end