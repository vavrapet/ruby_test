module User_model_patch
  def self.included(base)
    base.class_eval do
      def name_for_collection_select
        "#{lastname}, #{firstname}"
      end
    end
  end
end