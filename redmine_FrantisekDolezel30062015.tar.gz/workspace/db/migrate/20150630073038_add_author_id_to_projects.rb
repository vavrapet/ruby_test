class AddAuthorIdToProjects < ActiveRecord::Migration
  def change
    add_column :projects, :author_id, :string
    add_index :projects, :author_id
  end
end
