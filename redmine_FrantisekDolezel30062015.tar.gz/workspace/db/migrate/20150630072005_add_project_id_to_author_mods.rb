class AddProjectIdToAuthorMods < ActiveRecord::Migration
  def change
    add_column :author_mods, :project_id, :string
    add_index :author_mods, :project_id
    add_column :projects, :author_id, :string
    add_index :projects, :author_id
  end
end
