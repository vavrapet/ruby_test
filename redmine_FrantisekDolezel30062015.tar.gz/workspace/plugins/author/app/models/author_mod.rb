class AuthorMod < ActiveRecord::Base
#  def authors(answer)
#    increment(answer == 'yes' ? :yes : :no)
#  end
end
