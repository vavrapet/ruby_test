class AuthorConController < ApplicationController
  unloadable


  def index
    @authors=AuthorMod.all
  end
end
