class CreateAuthorMods < ActiveRecord::Migration
  def change
    create_table :author_mods do |t|
      t.string :name
      t.index :project_id
    end
  end
end
