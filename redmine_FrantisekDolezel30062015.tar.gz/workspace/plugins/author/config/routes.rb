# Plugin's routes
# See: http://guides.rubyonrails.org/routing.html
get 'authors', :to => 'author_con#index' 
#post 'post/:id/index', :to => 'authors#index' 
