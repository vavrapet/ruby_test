module CustomFieldsHelperPatch
  def self.included(base)
    base.extend ClassMethods

    base.overwrite_render_custom_fields_tabs

    base.instance_eval do
      def method_added(name)
        return if name != :render_custom_fields_tabs
        overwrite_render_custom_fields_tabs
      end
    end
  end

  module ClassMethods
    include CustomFieldsHelper

    def overwrite_render_custom_fields_tabs
      unless method_defined?(:custom_render_custom_fields_tabs)
        define_method(:custom_render_custom_fields_tabs) do |types|
          contact_field = {:name => 'ContactCustomField', :partial => 'custom_fields/index', :label => :label_contact}
          CUSTOM_FIELDS_TABS << contact_field if !CUSTOM_FIELDS_TABS.include?(contact_field)
          original_render_custom_fields_tabs(types)
        end
      end

      if instance_method(:render_custom_fields_tabs) != instance_method(:custom_render_custom_fields_tabs)
        alias_method :original_render_custom_fields_tabs, :render_custom_fields_tabs
        alias_method :render_custom_fields_tabs, :custom_render_custom_fields_tabs
      end
    end
  end
end