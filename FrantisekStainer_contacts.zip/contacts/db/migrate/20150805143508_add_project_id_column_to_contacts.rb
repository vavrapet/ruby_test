class AddProjectIdColumnToContacts < ActiveRecord::Migration
  def change
    add_column :contacts, :projects_id, :integer
  end
end
