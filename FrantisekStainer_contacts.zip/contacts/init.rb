Redmine::Plugin.register :contacts do
  name 'Contacts plugin'
  author 'Frantisek Stainer'
  description 'This is a contacts plugin for Redmine'
  version '0.0.1'

  project_module :contacts do
    permission :create_and_edit_contact, :contacts => [:new, :edit]
    permission :delete_contact, :contacts => :destroy
  end

  permission :view_contacts, :contacts => :index
  
  menu :project_menu, :contacts, { :controller => 'contacts', :action => 'index' }, :caption => 'Contacts', :after => :activity, :param => :project_id
  
  require 'custom_fields_helper'
  CustomFieldsHelper.send(:include, CustomFieldsHelperPatch)
  
  require 'project_patch'
  Project.send(:include, ProjectPatch)
end

Redmine::Search.available_search_types << 'contacts'
Redmine::Activity.register :contacts