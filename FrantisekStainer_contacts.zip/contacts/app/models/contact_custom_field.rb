class ContactCustomField < CustomField
  def type_name
    :label_contact
  end
end