class Contact < ActiveRecord::Base
  belongs_to :project

  attr_accessible :project_id
  attr_accessible :first_name
  attr_accessible :last_name
  attr_accessible :custom_field_values
  attr_accessible :attachments

  validates :first_name, presence: true
  validates :last_name, presence: true

  acts_as_customizable

  acts_as_attachable :delete_permission => :create_and_edit_contact

  acts_as_searchable :columns => [ "#{table_name}.first_name", "#{table_name}.last_name"]

  acts_as_event :title => Proc.new {|o| "Contact: #{o.first_name} #{o.last_name}"},
  :description => 'Contact.',
  :author => Proc.new {|o| o.attachments.reorder("#{Attachment.table_name}.created_on ASC").first.try(:author) },
  :url => Proc.new {|o| {:controller => 'contacts', :action => 'show', :id => o.id}}

  acts_as_activity_provider :scope => preload(:project)

  scope :visible, lambda {|*args|
    joins(:project)
  }

  def self.search(p_id, val)
    if val.nil?
      Contact.all
    else
      search_condition = "%" + val + "%"
      Contact.where('project_id = ? AND (first_name LIKE ? OR last_name LIKE ?)', p_id, search_condition, search_condition)
    end
  end
end
