class ContactsController < ApplicationController
  before_action :set_contact, only: [:show, :edit, :update, :destroy]
  before_filter :get_project, :authorize, only: [:new, :edit, :destroy]

  helper :attachments
  helper :custom_fields

  # GET /contacts
  # GET /contacts.json
  def index
    get_project

    @contacts = Contact.search(@project.id, params[:search].nil? ? '' : params[:search])
  end

  # GET /contacts/1
  # GET /contacts/1.json
  def show
    get_project

    @attachments = @contact.attachments.to_a
  end

  # GET /contacts/new
  def new
    get_project

    @contact = @project.contacts.build
  end

  # GET /contacts/1/edit
  def edit
    get_project
  end

  # POST /contacts
  # POST /contacts.json
  def create
    get_project

    p = get_contact_params
    p[:project_id] = @project.id
      
    @contact = @project.contacts.build(p)
    @contact.save_attachments(params[:attachments])

    respond_to do |format|
      if @contact.save
        render_attachment_warning_if_needed(@contact)
        format.html { redirect_to @contact, notice: 'Contact was successfully created.' }
        format.json { render :show, status: :created, location: @contact }
      else
        format.html { render :new }
        format.json { render json: @contact.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /contacts/1
  # PATCH/PUT /contacts/1.json
  def update
    get_project

    @contact.save_attachments(params[:attachments])
      
    respond_to do |format|
      if @contact.update(get_contact_params)
        format.html { redirect_to @contact, notice: 'Contact was successfully updated.' }
        format.json { render :show, status: :ok, location: @contact }
      else
        format.html { render :edit }
        format.json { render json: @contact.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /contacts/1
  # DELETE /contacts/1.json
  def destroy
    @contact.destroy
    respond_to do |format|
      format.html { redirect_to contacts_url, notice: 'Contact was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private

  # Use callbacks to share common setup or constraints between actions.
  def set_contact
    @contact = Contact.find(params[:id])
  end

  def get_project
    if !params[:project_id].nil?
      set_project_id(params[:project_id])
    end

    @project = Project.find(session[:project_id])
  end

  def set_project_id(val)
    session[:project_id] = val
  end

  def get_contact_params
    params.require(:contact).permit!
  end
end
