Redmine::Plugin.register :project_author do
  name 'Project Author plugin'
  author 'Franta Stainer'
  description 'Adds author selection field to project'
  version '0.0.1'
end

require 'user_model_patch'
User.send(:include, User_model_patch)

require 'project_model_patch'
Project.send(:include, Project_model_patch)

require 'project_helper_patch'
ProjectsHelper.send(:include, Project_helper_patch)