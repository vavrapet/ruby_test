module Project_model_patch
  def self.included(base)
    base.class_eval do
      attr_accessor :user_id
      safe_attributes "user_id"
      
      after_save {
        @authorMap = ProjectToAuthorMapping.find_by project_id: self.id

        if @authorMap.nil?
          @newMap = ProjectToAuthorMapping.new()
          @newMap.project_id = self.id
          @newMap.user_id = self.user_id
          @newMap.save
        else if @authorMap.user_id != self.user_id
          @authorMap.update_attribute :user_id, self.user_id
          end
        end
      }
    end
  end
end