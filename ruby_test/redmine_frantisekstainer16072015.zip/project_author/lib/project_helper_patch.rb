module Project_helper_patch
  def self.included(base)
    base.class_eval do
      def getUserId(project_id)
        @authorMap = ProjectToAuthorMapping.find_by project_id: project_id
        @authorMap.nil? ? 1 : @authorMap.user_id
      end
    end
  end
end