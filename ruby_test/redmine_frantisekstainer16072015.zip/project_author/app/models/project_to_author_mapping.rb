class ProjectToAuthorMapping < ActiveRecord::Base
end
